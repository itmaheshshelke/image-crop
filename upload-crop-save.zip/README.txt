A Pen created at CodePen.io. You can find this one at https://codepen.io/nakome/pen/vmKwQg.

 Thanks to https://github.com/fengyuanchen for cropper.js